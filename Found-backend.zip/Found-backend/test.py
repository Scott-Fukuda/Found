import app

# test listify
print(app.listify('["color1", "color2", "color3"]'))
print(["color1", "color2", "color3"])

print(app.listify("['color1', 'color2', 'color3']"))
print(['color1', 'color2', 'color3'])

#test sort_by_colors
items = [
            {
                "id": 1,
                "item name": "",
                "description": "yayy",
                "time created": "2024-11-24 19:37:13.361999",
                "location": "here",
                "current location": "",
                "color": "['blue']",
                "category": "Other",
                "finder number": 0,
                "finder email": "",
                "image": "url",
                "fulfilled": True,
                "user_id": 1
            },
            {
                "id": 2,
                "item name": "",
                "description": "yayy",
                "time created": "2024-11-24 21:45:21.182320",
                "location": "here",
                "current location": "",
                "color": "['blue']",
                "category": "Other",
                "finder number": 0,
                "finder email": "",
                "image": "url",
                "fulfilled": True,
                "user_id": 1
            },
            {
                "id": 3,
                "item name": "",
                "description": "yayy",
                "time created": "2024-11-24 21:45:22.198519",
                "location": "here",
                "current location": "",
                "color": "['blue']",
                "category": "Other",
                "finder number": 0,
                "finder email": "",
                "image": "url",
                "fulfilled": True,
                "user_id": 1
            },
            {
                "id": 4,
                "item name": "",
                "description": "yayy",
                "time created": "2024-11-24 21:45:23.133981",
                "location": "here",
                "current location": "",
                "color": "['blue']",
                "category": "Other",
                "finder number": 0,
                "finder email": "",
                "image": "url",
                "fulfilled": True,
                "user_id": 1
            },
            {
                "id": 5,
                "item name": "",
                "description": "yayy",
                "time created": "2024-11-24 21:45:24.209302",
                "location": "here",
                "current location": "",
                "color": "['blue']",
                "category": "Other",
                "finder number": 0,
                "finder email": "",
                "image": "url",
                "fulfilled": True,
                "user_id": 1
            }
        ]

clrs = "['blue']"

print(app.sort_by_color(items, clrs))